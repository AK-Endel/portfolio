Config = {}

Config.FF = 20
Config.F2 = 20
  
  Config.Zones = {
    Tabacchi = {
      Items = {},
        Pos = {
        {nome = 'Tööraamat', x = 1218.61,   y = -1267.27,  z = 36.42},  
        {nome = 'Töösõiduk', x = 1194.62,  y = -1286.95,  z = 34.12},
        {nome = 'Tagasta sõiduk', x = 1216.89,  y = -1229.23,  z = 34.40}, 
        {nome = 'Puude raiumine', x = -643.74,  y = 5241.68,  z = 75.19}, 
        {nome = 'Puude raiumine', x = -647.27,  y = 5269.43,  z = 74.07}, 
		{nome = 'Puude raiumine', x = -600.8,  y = 5240.7,  z = 71.48},
		{nome = 'Puude raiumine', x = -664.78,  y = 5240.7,  z = 71.48},
		{nome = 'Puude lõikus', x = -533.20,  y = 5277.26,  z = 74.4}, 
        {nome = 'Müü puitu', x = 497.32,  y = -1973.12,  z = 23.92},
        }
      }
  } 
  
  
  
 